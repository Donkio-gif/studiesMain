﻿using System;
using System.IO;
using System.Linq;
using System.Text;

class Program
{
    static void Main(string[] args)
    {
        Console.OutputEncoding = Encoding.UTF8;

        string path;
        if (args.Length > 0)
        {
            path = args[0];
        }
        else
        {
            Console.Write("Введите путь к файлу: ");
            path = (Console.ReadLine() ?? "").Trim().Trim('"');
        }

        long[] counts = new long[256];
        long n = 0;

        try
        {
            // Читаем сырые байты, без преобразования в текст.
            using (FileStream file = File.OpenRead(path))
            {
                byte[] buffer = new byte[8192];
                int read;

                while ((read = file.Read(buffer, 0, buffer.Length)) > 0)
                {
                    for (int i = 0; i < read; i++)
                    {
                        counts[buffer[i]]++;
                    }
                    n += read;
                }
            }
        }
        catch (Exception error) when (error is IOException ||
                                      error is UnauthorizedAccessException ||
                                      error is ArgumentException ||
                                      error is NotSupportedException)
        {
            Console.WriteLine("Не удалось прочитать файл: " + error.Message);
            return;
        }

        Console.WriteLine("\nФайл: " + path);
        Console.WriteLine("Длина файла: " + n + " байт");

        if (n == 0)
        {
            Console.WriteLine("Файл пуст. Вероятности по частотам не определены.");
            return;
        }

        double totalBits = 0;
        for (int j = 0; j < 256; j++)
        {
            if (counts[j] > 0)
            {
                double p = (double)counts[j] / n;
                double information = -Math.Log(p, 2);
                totalBits += counts[j] * information;
            }
        }

        int[] alphabetOrder = Enumerable.Range(0, 256).ToArray();
        int[] frequencyOrder = alphabetOrder
            .OrderByDescending(j => counts[j])
            .ThenBy(j => j)
            .ToArray();

        Console.WriteLine("\nТаблица по значению байта:");
        PrintTable(alphabetOrder, counts, n);
        Console.WriteLine("\nТаблица по убыванию частоты:");
        PrintTable(frequencyOrder, counts, n);

        double totalBytes = totalBits / 8;
        double fraction = totalBits - Math.Floor(totalBits);
        double e = Math.Ceiling(totalBytes);
        double g64 = e + 256 * 8;
        double g8 = e + 256;

        Console.WriteLine("\nИтоги:");
        Console.WriteLine($"L(Q) = {n} байт = {(decimal)n * 8} бит");
        Console.WriteLine($"IБ(Q) = {totalBits:F2} бит");
        Console.WriteLine($"Дробная часть IБ(Q) = {fraction:E6}");
        Console.WriteLine($"IБ(Q) = {totalBytes:F2} байт");
        Console.WriteLine($"E = {e:F0} байт (оценка снизу для сжатых данных)");
        Console.WriteLine($"G64 = {g64:F0} байт (E + 2048)");
        Console.WriteLine($"G8 = {g8:F0} байт (E + 256)");

        Console.WriteLine("\nСравнение с исходным файлом:");
        Console.WriteLine(g64 < n
            ? "G64 < n: по нижней оценке сжатие может быть выгодным."
            : "G64 >= n: даже нижняя оценка архива не меньше исходного файла.");
        Console.WriteLine(g8 < n
            ? "G8 < n: по нижней оценке сжатие может быть выгодным."
            : "G8 >= n: даже нижняя оценка архива не меньше исходного файла.");
        Console.WriteLine("Это оценки, а не размеры реально созданных архивов.");
        Console.WriteLine("G8 не учитывает изменение сжатия из-за огрубления частот.");
    }

    static void PrintTable(int[] order, long[] counts, long n)
    {
        Console.WriteLine("Байт |       Количество |    Вероятность p | IБ(байт), бит");
        foreach (int j in order)
        {
            double p = (double)counts[j] / n;
            string information = p > 0
                ? (-Math.Log(p, 2)).ToString("F6")
                : "+Infinity";

            Console.WriteLine($"{j:X2}   | {counts[j],16} | {p,17:E6} | {information,13}");
        }
    }
}

using System.Globalization;
using System.Text;

Console.OutputEncoding = Encoding.UTF8;
CultureInfo.CurrentCulture = CultureInfo.InvariantCulture;

string path;
if (args.Length > 0)
{
    path = args[0];
}
else
{
    Console.Write("Введите путь к файлу: ");
    path = Console.ReadLine()?.Trim().Trim('"') ?? "";
}

string? tablePath = null;
if (args.Length > 1)
{
    if (args.Length != 3 || args[1] != "--pairs")
    {
        Console.Error.WriteLine("Использование: Task24 <файл> [--pairs <таблица.csv>]");
        return 1;
    }
    tablePath = args[2];
}

try
{
    if (tablePath is not null &&
        Path.GetFullPath(path).Equals(Path.GetFullPath(tablePath),
                                      StringComparison.OrdinalIgnoreCase))
    {
        Console.Error.WriteLine("Таблица пар не может перезаписать исходный файл.");
        return 1;
    }
    Analysis result = Analyze(path);
    PrintReport(path, result);
    if (tablePath is not null)
    {
        WritePairs(tablePath, result);
        Console.WriteLine($"Полная таблица 256 × 256 пар сохранена: {tablePath}");
    }
}
catch (Exception error) when (error is IOException or UnauthorizedAccessException or
                              ArgumentException or NotSupportedException)
{
    Console.Error.WriteLine("Не удалось обработать файл: " + error.Message);
    return 1;
}

return 0;

static Analysis Analyze(string path)
{
    long[] byteCounts = new long[256];
    long[] pairCounts = new long[256 * 256];
    long[] rowTotals = new long[256];
    long length = 0;
    int previous = -1;
    byte[] buffer = new byte[64 * 1024];

    using FileStream file = File.OpenRead(path);
    int read;
    while ((read = file.Read(buffer)) > 0)
    {
        for (int i = 0; i < read; i++)
        {
            int current = buffer[i];
            byteCounts[current]++;
            if (previous >= 0)
            {
                pairCounts[(previous << 8) | current]++;
                rowTotals[previous]++;
            }
            previous = current;
            length++;
        }
    }

    return new Analysis(length, previous, byteCounts, pairCounts, rowTotals);
}

static void PrintReport(string path, Analysis data)
{
    Console.WriteLine($"Файл: {path}");
    Console.WriteLine($"Длина L(Q): {data.Length} октетов = {(decimal)data.Length * 8} бит");
    if (data.Length == 0)
    {
        Console.WriteLine("Файл пуст: первый символ и условные вероятности отсутствуют.");
        return;
    }

    double memorylessBits = 0;
    for (int value = 0; value < 256; value++)
    {
        long count = data.ByteCounts[value];
        if (count > 0)
            memorylessBits += count * -Math.Log2((double)count / data.Length);
    }

    // Первый байт имеет заданную в условии вероятность 1/256 и несёт 8 бит.
    double markovBits = 8;
    long distinctPairs = 0;
    for (int from = 0; from < 256; from++)
    {
        long rowTotal = data.RowTotals[from];
        for (int to = 0; to < 256; to++)
        {
            long count = data.PairCounts[(from << 8) | to];
            if (count == 0)
                continue;
            distinctPairs++;
            markovBits += count * -Math.Log2((double)count / rowTotal);
        }
    }

    long memorylessE = (long)Math.Ceiling(memorylessBits / 8);
    long markovE = (long)Math.Ceiling(markovBits / 8);
    const long denseTable64 = 256L * 256 * 8;
    const long denseTable8 = 256L * 256;
    const long lengthField = 8;
    long sparseTable64 = 8 + distinctPairs * 10; // m:64, затем m × (j:8, k:8, count:64).

    Console.WriteLine($"Всего пар: {data.Length - 1}; различных пар: {distinctPairs}");
    Console.WriteLine($"Последний байт: {data.LastByte:X2}; " +
                      "count(j*) = count(j) - 1 именно для этого байта");
    Console.WriteLine($"\nЛ2.№1, источник без памяти: IБ(Q) = {memorylessBits:F2} бит = {memorylessBits / 8:F2} октетов");
    Console.WriteLine($"Дробная часть IБ(Q) [бит] = {memorylessBits - Math.Floor(memorylessBits):E6}");
    Console.WriteLine($"EБ = {memorylessE} октетов; G64 = {memorylessE + 2048} октетов; " +
                      $"G8 = {memorylessE + 256} октетов");
    Console.WriteLine($"\nЛ2.№4, Марков 1-го порядка: IСМ1(Q) = {markovBits:F2} бит = {markovBits / 8:F2} октетов");
    Console.WriteLine($"Дробная часть IСМ1(Q) [бит] = {markovBits - Math.Floor(markovBits):E6}");
    Console.WriteLine($"EСМ1 = {markovE} октетов; разница IБ - IСМ1 = {memorylessBits - markovBits:F2} бит");
    Console.WriteLine("Для первого байта учтено -log2(1/256) = 8 бит.");

    Console.WriteLine("\nДанные для декодирования (count(j*) получается суммированием строки):");
    Console.WriteLine($"Плотная таблица 256 × 256 × 8 байт: {denseTable64} октетов");
    Console.WriteLine($"Архив с ней, 8-байтной исходной длиной и EСМ1: {markovE + denseTable64 + lengthField} октетов");
    Console.WriteLine($"Разреженная таблица: 8 + {distinctPairs} × 10 = {sparseTable64} октетов");
    Console.WriteLine($"Архив с ней, длиной и EСМ1: {markovE + sparseTable64 + lengthField} октетов");
    Console.WriteLine($"Гипотетическая плотная таблица 8-битных частот: {denseTable8} октетов " +
                      "(для больших count нужна нормировка)");
    Console.WriteLine($"Архив с 8-битной таблицей, длиной и EСМ1: {markovE + denseTable8 + lengthField} октетов");
    Console.WriteLine("Это оценки снизу, не размеры реальных архивов.");

    Console.WriteLine("\nСамые частые пары (байты в шестнадцатеричном виде):");
    Console.WriteLine("Пара | count(jk) | count(j*) | p(k|j)");
    foreach (int index in Enumerable.Range(0, 256 * 256)
                 .Where(index => data.PairCounts[index] > 0)
                 .OrderByDescending(index => data.PairCounts[index])
                 .ThenBy(index => index)
                 .Take(12))
    {
        int from = index >> 8;
        int to = index & 0xFF;
        long count = data.PairCounts[index];
        Console.WriteLine($"{from:X2} {to:X2} | {count,9} | {data.RowTotals[from],9} | " +
                          $"{(double)count / data.RowTotals[from]:F6}");
    }
}

static void WritePairs(string path, Analysis data)
{
    using StreamWriter writer = new(path, false, new UTF8Encoding(false));
    writer.WriteLine("from_hex,to_hex,count_pair,count_from_star,p_to_given_from");
    for (int from = 0; from < 256; from++)
    {
        long rowTotal = data.RowTotals[from];
        for (int to = 0; to < 256; to++)
        {
            long count = data.PairCounts[(from << 8) | to];
            string probability = rowTotal == 0
                ? "" // Условная вероятность не определена, если j не начинает ни одну пару.
                : ((double)count / rowTotal).ToString("G17", CultureInfo.InvariantCulture);
            writer.WriteLine($"{from:X2},{to:X2},{count},{rowTotal},{probability}");
        }
    }
}

sealed record Analysis(
    long Length,
    int LastByte,
    long[] ByteCounts,
    long[] PairCounts,
    long[] RowTotals);

using System.IO.Compression;
using System.Text;

Console.OutputEncoding = Encoding.UTF8;

string zipPath;
if (args.Length > 0)
{
    zipPath = args[0];
}
else
{
    Console.Write("Путь к архиву otik-master-labs-files.zip: ");
    zipPath = Console.ReadLine()?.Trim().Trim('"') ?? "";
}

// Номер команды для этой работы: № 8. Вторым аргументом его можно переопределить.
long teamNumber = 8;
if (args.Length > 1)
{
    if (!long.TryParse(args[1], out long number) || number < 1)
    {
        Console.Error.WriteLine("Номер команды должен быть положительным целым числом.");
        return 1;
    }
    teamNumber = number;
}

try
{
    using ZipArchive archive = ZipFile.OpenRead(zipPath);
    FileStats[] references = archive.Entries
        .Where(entry => entry.FullName.Contains(
                    "labs-files/Файлы в формате простого текста — кодировки разные/",
                    StringComparison.Ordinal) &&
                (entry.Name.StartsWith("Керниган, Ричи.", StringComparison.Ordinal) ||
                 entry.Name.StartsWith("Льюис Кэрролл.", StringComparison.Ordinal)))
        .Select(entry => Analyze(entry, ReferenceLabel(entry.Name)))
        .OrderBy(stats => stats.Label)
        .ToArray();

    if (references.Length != 16 ||
        references.Select(stats => stats.Encoding).Distinct().Count() != 8)
        throw new InvalidDataException("В архиве не найдены два русских текста во всех восьми кодировках.");

    Console.WriteLine("Частоты в двух русских текстах во всех представленных кодировках");
    Console.WriteLine("Печатные символы ASCII имеют коды 20..7E; во второй четвёрке они исключены.");
    foreach (FileStats stats in references)
        PrintStats(stats);

    int variant = (int)((teamNumber - 1) % 9);
    string expectedSuffix = $"/Варианты 2 — определение кодировки простого текста/{variant}.txt";
    ZipArchiveEntry? variantEntry = archive.Entries.SingleOrDefault(
        entry => entry.FullName.EndsWith(expectedSuffix, StringComparison.Ordinal));
    if (variantEntry is null)
        throw new InvalidDataException($"В архиве отсутствует файл варианта {variant}.txt.");

    FileStats unknown = Analyze(variantEntry, $"W, вариант {variant}", "кодировка неизвестна");
    Console.WriteLine($"\nДля № {teamNumber}: (№ - 1) % 9 = {variant}");
    PrintStats(unknown);

    var ranking = references
        .GroupBy(stats => stats.Encoding)
        .Select(group => new
        {
            Encoding = group.Key,
            Distance = group.Min(stats => TotalVariation(unknown, stats))
        })
        .OrderBy(item => item.Distance)
        .ToArray();

    Console.WriteLine("\nСравнение W с русскими текстами (расстояние между распределениями байтов):");
    foreach (var item in ranking)
        Console.WriteLine($"{item.Encoding,-11} {item.Distance:F3}");

    double referenceDistance = references
        .GroupBy(stats => stats.Encoding)
        .Max(group => TotalVariation(group.First(), group.Last()));
    Console.WriteLine($"Наибольшее расстояние между двумя русскими текстами в одной кодировке: {referenceDistance:F3}.");
    Console.WriteLine("Меньшее расстояние означает большее сходство; это подсказка, не доказательство кодировки.");

    if (ranking[0].Distance > 1.5 * referenceDistance)
        Console.WriteLine("W заметно отличается от русского корпуса; проверьте, не является ли текст нерусскоязычным.");
    else if (ranking[1].Distance - ranking[0].Distance < 0.01)
        Console.WriteLine("Два лучших кандидата близки: нужны дополнительные признаки и проверка чтением.");
    else
        Console.WriteLine($"Наиболее вероятная кодировка по частотам: {ranking[0].Encoding}.");
}
catch (Exception error) when (error is IOException or UnauthorizedAccessException or
                              ArgumentException or InvalidDataException)
{
    Console.Error.WriteLine("Не удалось выполнить анализ: " + error.Message);
    return 1;
}

return 0;

static FileStats Analyze(ZipArchiveEntry entry, string label, string? encoding = null)
{
    long[] counts = new long[256];
    long length = 0;
    byte[] buffer = new byte[64 * 1024];
    using Stream stream = entry.Open();
    int read;
    while ((read = stream.Read(buffer)) > 0)
    {
        for (int i = 0; i < read; i++)
            counts[buffer[i]]++;
        length += read;
    }
    return new FileStats(label, encoding ?? EncodingName(entry.Name), length, counts);
}

static string ReferenceLabel(string name) =>
    name.StartsWith("Керниган", StringComparison.Ordinal) ? "Керниган/Ричи" : "Кэрролл";

static string EncodingName(string name)
{
    int separator = name.LastIndexOf(" — ", StringComparison.Ordinal);
    return separator < 0 ? "?" : Path.GetFileNameWithoutExtension(name[(separator + 3)..]);
}

static void PrintStats(FileStats stats)
{
    Console.WriteLine($"\n{stats.Label}, {stats.Encoding}; {stats.Length} октетов");
    Console.WriteLine("  Все октеты:                  " + TopFour(stats, _ => true));
    Console.WriteLine("  Вне печатных кодов ASCII:   " +
                      TopFour(stats, value => value < 0x20 || value > 0x7E));
}

static string TopFour(FileStats stats, Func<int, bool> include) =>
    string.Join(", ", Enumerable.Range(0, 256)
        .Where(value => include(value) && stats.Counts[value] > 0)
        .OrderByDescending(value => stats.Counts[value])
        .ThenBy(value => value)
        .Take(4)
        .Select(value => $"{value:X2}: {stats.Counts[value]} " +
                         $"({100.0 * stats.Counts[value] / stats.Length:F1}%)"));

static double TotalVariation(FileStats left, FileStats right)
{
    double distance = 0;
    for (int value = 0; value < 256; value++)
        distance += Math.Abs((double)left.Counts[value] / left.Length -
                             (double)right.Counts[value] / right.Length);
    return distance / 2;
}

sealed record FileStats(string Label, string Encoding, long Length, long[] Counts);

using System.Buffers;
using System.Globalization;
using System.Text;

Console.OutputEncoding = Encoding.UTF8;
CultureInfo.CurrentCulture = CultureInfo.InvariantCulture;

bool summaryOnly = args.Contains("--summary");
string[] paths = args.Where(arg => arg != "--summary").ToArray();

if (paths.Length == 0)
{
    Console.Write("Введите путь к текстовому файлу UTF-8: ");
    string? path = Console.ReadLine()?.Trim().Trim('"');
    if (string.IsNullOrEmpty(path))
    {
        Console.Error.WriteLine("Путь к файлу не задан.");
        return 1;
    }
    paths = [path];
}

foreach (string path in paths)
{
    try
    {
        FileAnalysis analysis = Analyze(path);
        PrintReport(path, analysis, summaryOnly);
    }
    catch (Exception error) when (error is IOException or InvalidDataException or UnauthorizedAccessException
                                  or ArgumentException or NotSupportedException)
    {
        Console.Error.WriteLine($"Не удалось обработать «{path}»: {error.Message}");
        return 1;
    }
}

return 0;

static FileAnalysis Analyze(string path)
{
    long[] byteCounts = new long[256];
    Dictionary<Rune, long> runeCounts = [];
    long byteCount = 0;
    long runeCount = 0;

    // На границе блоков может находиться часть 2-, 3- или 4-байтового UTF-8 символа.
    byte[] buffer = new byte[64 * 1024 + 4];
    int pending = 0;
    using FileStream file = File.OpenRead(path);

    while (true)
    {
        int read = file.Read(buffer.AsSpan(pending));
        int length = pending + read;
        if (length == 0)
            break;

        for (int i = pending; i < length; i++)
            byteCounts[buffer[i]]++;
        byteCount += read;

        int position = 0;
        while (position < length)
        {
            OperationStatus status = Rune.DecodeFromUtf8(
                buffer.AsSpan(position, length - position), out Rune rune, out int consumed);

            if (status == OperationStatus.Done)
            {
                runeCounts[rune] = runeCounts.GetValueOrDefault(rune) + 1;
                runeCount++;
                position += consumed;
            }
            else if (status == OperationStatus.NeedMoreData && read > 0)
            {
                break;
            }
            else
            {
                long offset = byteCount - length + position;
                throw new InvalidDataException(
                    $"Некорректный UTF-8 возле байта {offset}. Для Л2.№2 нужен текст UTF-8.");
            }
        }

        pending = length - position;
        buffer.AsSpan(position, pending).CopyTo(buffer);

        if (read == 0)
            break;
    }

    return new FileAnalysis(byteCounts, runeCounts, byteCount, runeCount);
}

static double InformationBits(IEnumerable<long> counts, long length)
{
    if (length == 0)
        return 0;

    double total = 0;
    foreach (long count in counts)
    {
        if (count == 0)
            continue;
        double probability = (double)count / length;
        total += count * -Math.Log2(probability);
    }
    return total;
}

static void PrintReport(string path, FileAnalysis analysis, bool summaryOnly)
{
    long nBytes = analysis.ByteCount;
    long nRunes = analysis.RuneCount;
    int alphabetSize = analysis.RuneCounts.Count;

    Console.WriteLine($"\nФайл: {path}");
    Console.WriteLine($"Длина исходного UTF-8 файла: {nBytes} октетов = {(decimal)nBytes * 8} бит");
    Console.WriteLine($"Символов Unicode (кодовых точек): {nRunes}; различных: {alphabetSize}");
    if (nRunes == 0)
    {
        Console.WriteLine("Файл пуст: вероятности и информация на символ не определены.");
        return;
    }

    double byteBits = InformationBits(analysis.ByteCounts, nBytes);
    double runeBits = InformationBits(analysis.RuneCounts.Values, nRunes);
    long byteE = (long)Math.Ceiling(byteBits / 8);
    long runeE = (long)Math.Ceiling(runeBits / 8);

    Console.WriteLine("\nМодель Л2.№1 (символ = байт):");
    Console.WriteLine($"IБ(Q) = {byteBits:F2} бит = {byteBits / 8:F2} октетов; E = {byteE} октетов");
    Console.WriteLine($"Дробная часть IБ(Q) [бит] = {byteBits - Math.Floor(byteBits):E6}");
    Console.WriteLine($"G64 = {byteE + 256L * 8} октетов; G8 = {byteE + 256} октетов");

    Console.WriteLine("\nМодель Л2.№2 (символ = кодовая точка Unicode):");
    Console.WriteLine($"IБ(Q) = {runeBits:F2} бит = {runeBits / 8:F2} октетов; E = {runeE} октетов");
    Console.WriteLine($"Дробная часть IБ(Q) [бит] = {runeBits - Math.Floor(runeBits):E6}");
    Console.WriteLine($"Разница IБ(№1) - IБ(№2) = {byteBits - runeBits:F2} бит");

    long utf8Symbols = analysis.RuneCounts.Keys.Sum(rune => (long)rune.Utf8SequenceLength);
    long utf16Symbols = analysis.RuneCounts.Keys.Sum(rune => (long)rune.Utf16SequenceLength * 2);
    long utf32Symbols = 4L * alphabetSize;

    Console.WriteLine("\nАрхив Л2.№2: 8 октетов для |A1| + пары (символ, частота) + E:");
    PrintArchive("UTF-8", utf8Symbols, alphabetSize, runeE);
    PrintArchive("UTF-16", utf16Symbols, alphabetSize, runeE);
    PrintArchive("UTF-32", utf32Symbols, alphabetSize, runeE);

    const long unicodeCodeSpace = 0x110000; // Коды 0..0x10FFFF, включая незанятые позиции.
    Console.WriteLine("\nЕсли хранить частоты для всего пространства кодов Unicode:");
    Console.WriteLine($"Таблица из 64-битных частот: {unicodeCodeSpace * 8} октетов; архив: {runeE + unicodeCodeSpace * 8} октетов");
    Console.WriteLine($"Таблица из 8-битных частот:  {unicodeCodeSpace} октетов; архив: {runeE + unicodeCodeSpace} октетов");
    Console.WriteLine("8-битные частоты требуют нормировки, если исходный count > 255;");
    Console.WriteLine("G8 — оценка по исходному распределению, а не размер готового кодированного файла.");

    if (summaryOnly)
        return;

    Console.WriteLine("\nТаблица символов Unicode по кодовой точке:");
    PrintTable(analysis.RuneCounts.OrderBy(entry => entry.Key.Value), nRunes);
    Console.WriteLine("\nТаблица символов Unicode по убыванию частоты:");
    PrintTable(analysis.RuneCounts.OrderByDescending(entry => entry.Value)
                                  .ThenBy(entry => entry.Key.Value), nRunes);
}

static void PrintArchive(string encoding, long symbolBytes, int alphabetSize, long compressedBytes)
{
    long header64 = 8 + symbolBytes + 8L * alphabetSize;
    long header8 = 8 + symbolBytes + alphabetSize;
    Console.WriteLine($"{encoding,-6}: коды символов = {symbolBytes}; " +
                      $"заголовок 64/8 бит = {header64}/{header8}; " +
                      $"архив G64/G8 = {compressedBytes + header64}/{compressedBytes + header8} октетов");
}

static void PrintTable(IEnumerable<KeyValuePair<Rune, long>> entries, long length)
{
    Console.WriteLine("Код Unicode | Символ |     Количество | Вероятность p | IБ(символ), бит");
    foreach ((Rune rune, long count) in entries)
    {
        double probability = (double)count / length;
        double information = -Math.Log2(probability);
        Console.WriteLine($"{($"U+{rune.Value:X4}"),-11} | {DisplayRune(rune),-6} | {count,14} | " +
                          $"{probability,13:E6} | {information,15:F6}");
    }
}

static string DisplayRune(Rune rune) => rune.Value switch
{
    0x09 => "\\t",
    0x0A => "\\n",
    0x0D => "\\r",
    0x20 => "SPACE",
    0xFEFF => "BOM",
    _ => Rune.GetUnicodeCategory(rune) switch
    {
        UnicodeCategory.Control or UnicodeCategory.Format or
        UnicodeCategory.LineSeparator or UnicodeCategory.ParagraphSeparator or
        UnicodeCategory.SpaceSeparator => "(служ.)",
        _ => rune.ToString()
    }
};

sealed record FileAnalysis(
    long[] ByteCounts,
    Dictionary<Rune, long> RuneCounts,
    long ByteCount,
    long RuneCount);

using System.Buffers;
using System.Globalization;
using System.Text;

Console.OutputEncoding = Encoding.UTF8;
CultureInfo.CurrentCulture = CultureInfo.InvariantCulture;

string path;
if (args.Length > 0)
{
    path = args[0];
}
else
{
    Console.Write("Введите путь к текстовому файлу UTF-8: ");
    path = Console.ReadLine()?.Trim().Trim('"') ?? "";
}

string? tablePath = null;
if (args.Length > 1)
{
    if (args.Length != 3 || args[1] != "--pairs")
    {
        Console.Error.WriteLine("Использование: Task25 <UTF-8 файл> [--pairs <таблица.csv>]");
        return 1;
    }
    tablePath = args[2];
}

try
{
    if (tablePath is not null &&
        Path.GetFullPath(path).Equals(Path.GetFullPath(tablePath),
                                      StringComparison.OrdinalIgnoreCase))
    {
        Console.Error.WriteLine("Таблица пар не может перезаписать исходный файл.");
        return 1;
    }

    Analysis result = Analyze(path);
    PrintReport(path, result);
    if (tablePath is not null)
    {
        WritePairs(tablePath, result);
        Console.WriteLine($"Полная таблица Unicode-пар сохранена: {tablePath}");
    }
}
catch (Exception error) when (error is IOException or InvalidDataException or UnauthorizedAccessException or
                              ArgumentException or NotSupportedException)
{
    Console.Error.WriteLine("Не удалось обработать файл: " + error.Message);
    return 1;
}

return 0;

static Analysis Analyze(string path)
{
    long[] byteCounts = new long[256];
    long[] bytePairCounts = new long[256 * 256];
    long[] byteRowTotals = new long[256];
    Dictionary<Rune, long> runeCounts = [];
    Dictionary<(Rune From, Rune To), long> runePairCounts = [];
    Dictionary<Rune, long> runeRowTotals = [];
    long byteCount = 0;
    long runeCount = 0;
    int previousByte = -1;
    Rune? previousRune = null;

    // Оставляем место для незаконченной 2-, 3- или 4-байтовой последовательности.
    byte[] buffer = new byte[64 * 1024 + 4];
    int pending = 0;
    using FileStream file = File.OpenRead(path);

    while (true)
    {
        int read = file.Read(buffer.AsSpan(pending));
        int length = pending + read;
        if (length == 0)
            break;

        // Байты из pending уже были посчитаны на предыдущей итерации.
        for (int i = pending; i < length; i++)
        {
            int current = buffer[i];
            byteCounts[current]++;
            if (previousByte >= 0)
            {
                bytePairCounts[(previousByte << 8) | current]++;
                byteRowTotals[previousByte]++;
            }
            previousByte = current;
            byteCount++;
        }

        int position = 0;
        while (position < length)
        {
            OperationStatus status = Rune.DecodeFromUtf8(
                buffer.AsSpan(position, length - position), out Rune rune, out int consumed);
            if (status == OperationStatus.Done)
            {
                runeCounts[rune] = runeCounts.GetValueOrDefault(rune) + 1;
                if (previousRune is Rune previous)
                {
                    var pair = (previous, rune);
                    runePairCounts[pair] = runePairCounts.GetValueOrDefault(pair) + 1;
                    runeRowTotals[previous] = runeRowTotals.GetValueOrDefault(previous) + 1;
                }
                previousRune = rune;
                runeCount++;
                position += consumed;
            }
            else if (status == OperationStatus.NeedMoreData && read > 0)
            {
                break;
            }
            else
            {
                long offset = byteCount - length + position;
                throw new InvalidDataException($"Некорректный UTF-8 возле байта {offset}.");
            }
        }

        pending = length - position;
        buffer.AsSpan(position, pending).CopyTo(buffer);
        if (read == 0)
            break;
    }

    return new Analysis(byteCount, runeCount, previousByte, previousRune,
                        byteCounts, bytePairCounts, byteRowTotals,
                        runeCounts, runePairCounts, runeRowTotals);
}

static void PrintReport(string path, Analysis data)
{
    Console.WriteLine($"Файл: {path}");
    Console.WriteLine($"Исходная длина: {data.ByteCount} октетов = {(decimal)data.ByteCount * 8} бит");
    Console.WriteLine($"Символов Unicode: {data.RuneCount}; различных символов |A1|: {data.RuneCounts.Count}");
    if (data.RuneCount == 0)
    {
        Console.WriteLine("Файл пуст: первый символ и условные вероятности отсутствуют.");
        return;
    }

    double byteMemoryless = MemorylessInformation(data.ByteCounts, data.ByteCount);
    double runeMemoryless = MemorylessInformation(data.RuneCounts.Values, data.RuneCount);
    double byteMarkov = 8; // p(c1) = 1/256 из Л2.№4.
    long distinctBytePairs = 0;
    for (int from = 0; from < 256; from++)
    {
        long rowTotal = data.ByteRowTotals[from];
        for (int to = 0; to < 256; to++)
        {
            long count = data.BytePairCounts[(from << 8) | to];
            if (count == 0)
                continue;
            distinctBytePairs++;
            byteMarkov += count * -Math.Log2((double)count / rowTotal);
        }
    }

    // В Л2.№2 A1 — множество символов Unicode именно этого файла.
    double runeMarkov = Math.Log2(data.RuneCounts.Count);
    foreach (((Rune from, Rune _), long count) in data.RunePairCounts)
        runeMarkov += count * -Math.Log2((double)count / data.RuneRowTotals[from]);

    long byteMarkovE = (long)Math.Ceiling(byteMarkov / 8);
    long runeMemorylessE = (long)Math.Ceiling(runeMemoryless / 8);
    long runeMarkovE = (long)Math.Ceiling(runeMarkov / 8);
    long alphabetSize = data.RuneCounts.Count;
    long distinctRunePairs = data.RunePairCounts.Count;

    Console.WriteLine("\nСопоставление моделей на одном и том же UTF-8 файле:");
    Console.WriteLine($"Л2.№2, символ = Unicode: IБ = {runeMemoryless:F2} бит = {runeMemoryless / 8:F2} октетов");
    Console.WriteLine($"Л2.№5, символ = Unicode: IСМ1 = {runeMarkov:F2} бит = {runeMarkov / 8:F2} октетов");
    Console.WriteLine($"Л2.№1, символ = байт:    IБ = {byteMemoryless:F2} бит = {byteMemoryless / 8:F2} октетов");
    Console.WriteLine($"Л2.№4, символ = байт:    IСМ1 = {byteMarkov:F2} бит = {byteMarkov / 8:F2} октетов");
    Console.WriteLine($"Для первого Unicode-символа: p = 1/|A1| = 1/{alphabetSize}, " +
                      $"I = log2(|A1|) = {Math.Log2(alphabetSize):F6} бит");
    Console.WriteLine($"Если считать начальный символ равновероятным по всему пространству Unicode, " +
                      $"вместо этого было бы log2(0x110000) = {Math.Log2(0x110000):F6} бит, " +
                      $"а IСМ1(Q) = {runeMarkov - Math.Log2(alphabetSize) + Math.Log2(0x110000):F2} бит");
    Console.WriteLine($"Пар байтов: {data.ByteCount - 1}, различных: {distinctBytePairs}; " +
                      $"пар Unicode: {data.RuneCount - 1}, различных: {distinctRunePairs}");
    Console.WriteLine($"Последний Unicode-символ: U+{data.LastRune!.Value.Value:X4}; " +
                      "для него count(a*) = count(a) - 1");

    long utf8Alphabet = 8 + data.RuneCounts.Keys.Sum(rune => (long)rune.Utf8SequenceLength);
    long denseUnicodeTable = 8 * alphabetSize * alphabetSize;
    long sparseUnicodeTable = 8 + data.RunePairCounts.Sum(entry =>
        8L + entry.Key.From.Utf8SequenceLength + entry.Key.To.Utf8SequenceLength);
    const long lengthField = 8;
    long byteSparseTable = 8 + 10 * distinctBytePairs;

    Console.WriteLine("\nОценки архива (октеты, частоты по 64 бита, коды Unicode в UTF-8):");
    Console.WriteLine($"Л2.№2 без памяти: E = {runeMemorylessE}, " +
                      $"архив = {runeMemorylessE + utf8Alphabet + 8 * alphabetSize}");
    Console.WriteLine($"Л2.№5 с памятью: E = {runeMarkovE}, " +
                      $"плотная таблица = {denseUnicodeTable}, " +
                      $"архив = {runeMarkovE + utf8Alphabet + denseUnicodeTable + lengthField}");
    Console.WriteLine($"Л2.№5 с памятью: разреженная таблица = {sparseUnicodeTable}, " +
                      $"архив = {runeMarkovE + utf8Alphabet + sparseUnicodeTable + lengthField}");
    Console.WriteLine($"Л2.№4 по байтам: E = {byteMarkovE}, " +
                      $"архив с плотной таблицей = {byteMarkovE + 524288 + lengthField}, " +
                      $"с разреженной = {byteMarkovE + byteSparseTable + lengthField}");
    Console.WriteLine("Это оценки снизу по исходным частотам, а не размеры созданных архивов.");

    Console.WriteLine("\nСамые частые соседние символы Unicode:");
    Console.WriteLine("Пара | count(jk) | count(j*) | p(k|j)");
    foreach (var entry in data.RunePairCounts
                 .OrderByDescending(entry => entry.Value)
                 .ThenBy(entry => entry.Key.From.Value)
                 .ThenBy(entry => entry.Key.To.Value)
                 .Take(12))
    {
        Rune from = entry.Key.From;
        Rune to = entry.Key.To;
        long rowTotal = data.RuneRowTotals[from];
        Console.WriteLine($"U+{from.Value:X4} U+{to.Value:X4} | {entry.Value,9} | {rowTotal,9} | " +
                          $"{(double)entry.Value / rowTotal:F6}");
    }
}

static double MemorylessInformation(IEnumerable<long> counts, long length)
{
    double total = 0;
    foreach (long count in counts)
    {
        if (count > 0)
            total += count * -Math.Log2((double)count / length);
    }
    return total;
}

static void WritePairs(string path, Analysis data)
{
    Rune[] alphabet = data.RuneCounts.Keys.OrderBy(rune => rune.Value).ToArray();
    using StreamWriter writer = new(path, false, new UTF8Encoding(false));
    writer.WriteLine("from_unicode,to_unicode,count_pair,count_from_star,p_to_given_from");
    foreach (Rune from in alphabet)
    {
        long rowTotal = data.RuneRowTotals.GetValueOrDefault(from);
        foreach (Rune to in alphabet)
        {
            long count = data.RunePairCounts.GetValueOrDefault((from, to));
            string probability = rowTotal == 0
                ? "" // Нет пар с начальным символом from: p(k|from) не определена.
                : ((double)count / rowTotal).ToString("G17", CultureInfo.InvariantCulture);
            writer.WriteLine($"U+{from.Value:X4},U+{to.Value:X4},{count},{rowTotal},{probability}");
        }
    }
}

sealed record Analysis(
    long ByteCount,
    long RuneCount,
    int LastByte,
    Rune? LastRune,
    long[] ByteCounts,
    long[] BytePairCounts,
    long[] ByteRowTotals,
    Dictionary<Rune, long> RuneCounts,
    Dictionary<(Rune From, Rune To), long> RunePairCounts,
    Dictionary<Rune, long> RuneRowTotals);
